import { Component } from '@angular/core';

@Component({
  selector: 'app-ai-heading',
  templateUrl: './ai-heading.component.html',
  styleUrls: ['./ai-heading.component.css']
})
export class AiHeadingComponent {

}
